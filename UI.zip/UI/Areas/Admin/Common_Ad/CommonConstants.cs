﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UI.Areas.Admin.Common
{
    public class CommonConstants
    {
        public static string ACCOUNT_SESSION = "ACCOUNT_SESSION";
    }
}