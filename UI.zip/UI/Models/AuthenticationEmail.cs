﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UI.Models
{
    public class AuthenticationEmail
    {
        public string Email { get; set; }
        public string AuthenticationCode { get; set; }
    }
}